ROS Navigation Stack
--------------------

A 2D navigation stack that takes in information from odometry, sensor
streams, and a goal pose and outputs safe velocity commands that are sent
to a mobile base.

Related stacks:

 * http://github.com/ros-planning/navigation_tutorials
 * http://github.com/ros-planning/navigation_experimental
